//
//  ViewController.swift
//  CameraTest
//
//  Created by Sudhakar Tharigoppula on 16/04/19.
//  Copyright © 2019 Valuelabs. All rights reserved.
//

import UIKit

class ImageTableCell: UITableViewCell {
  @IBOutlet weak var imgView: UIImageView!
}

class ViewController: UIViewController {
  @IBOutlet weak var tableView: UITableView!
  
  var imagesList: [String] = []
  let selIndex: Int = 1

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  @IBAction func takePuctureAction(_ sender: UIBarButtonItem) {
    
    
   
    let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
    alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
      self.openCamera()
    }))
    
    alert.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { _ in
      self.openGallary()
    }))
    
    alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
    
    if let popoverController = alert.popoverPresentationController {
      popoverController.barButtonItem = sender
      popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
    }
    
    self.present(alert, animated: true, completion: nil)
    
  }
  
  //MARK: - Open the camera
  func openCamera() {
    if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
      let imagePicker = UIImagePickerController()
      imagePicker.delegate = self
      imagePicker.sourceType = .camera
      self.present(imagePicker, animated: true, completion: nil)
    }
    else{
      let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
      alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
      self.present(alert, animated: true, completion: nil)
    }
  }
  
  //MARK: - Choose image from camera roll
  func openGallary() {
    let imagePicker = UIImagePickerController()
    imagePicker.delegate = self
    imagePicker.sourceType = .photoLibrary
    self.present(imagePicker, animated: true, completion: nil)
  }
  
  
  func savedImagesPath()->String? {
      var paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as [String]
      let imagesPath = paths[0] + "/" + "Images"
      if !FileManager.default.fileExists(atPath: imagesPath) {
        do {
          try FileManager.default.createDirectory(atPath: imagesPath, withIntermediateDirectories: true, attributes: nil)
        } catch {
          print("Couldn't create document directory")
        }
      }
      return imagesPath
  }
}

//MARK: - UIImagePickerControllerDelegate

extension ViewController:  UIImagePickerControllerDelegate, UINavigationControllerDelegate {
  
  func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    // Local variable inserted by Swift 4.2 migrator.
    let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)
    guard let selectedImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as? UIImage else {
      fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
    }
    let pathTobeSaved = (self.savedImagesPath() ?? "")
    if FileManager.default.fileExists(atPath: pathTobeSaved) {
      //+ "/" + "\(selIndex).png"
      do {
        let items = try FileManager.default.contentsOfDirectory(atPath: pathTobeSaved)
        let path = pathTobeSaved + "/" + "\(items.count+1).png"
        let imageData = selectedImage.jpegData(compressionQuality: 1.0)
        let urlPath = URL(fileURLWithPath:path)
        try imageData?.write(to: urlPath)
        imagesList.append(path)
        tableView.reloadData()
      } catch {
        
      }
    }
    //Dismiss the UIImagePicker after selection
    picker.dismiss(animated: true, completion: nil)
  }
  
  func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
    picker.isNavigationBarHidden = false
    self.dismiss(animated: true, completion: nil)
  }
  
  // Helper function inserted by Swift 4.2 migrator.
   func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
    return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
  }
  
  // Helper function inserted by Swift 4.2 migrator.
  fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
    return input.rawValue
  }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return imagesList.count
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "ImageTableCell", for: indexPath) as! ImageTableCell
    let path = imagesList[indexPath.row]
    cell.imageView?.image = UIImage(contentsOfFile: path)
    print(indexPath.row)
    return cell
  }
  
}
